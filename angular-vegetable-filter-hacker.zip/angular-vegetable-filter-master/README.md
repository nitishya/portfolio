# This is an angular application for filtering.

# Implement the search filter for application and that should display the searched items when performing the search..
