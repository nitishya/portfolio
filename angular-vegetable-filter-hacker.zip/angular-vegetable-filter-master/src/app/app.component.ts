import { Component } from '@angular/core';
import { SearchComponent } from './search/search.component';
import { ListComponent } from './list/list.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {}
